using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviourPunCallbacks
{
    public static ScoreManager Instance;
    private Dictionary<int, int> playerScores = new Dictionary<int, int>(); // ID du joueur -> Score
    public TextMeshProUGUI scoreText;
    public int winningScore = 10;
    
    void Start()
    {
        if (PhotonNetwork.IsConnected)
        {
            foreach (Player player in PhotonNetwork.PlayerList)
            {
                if (!playerScores.ContainsKey(player.ActorNumber))
                {
                    playerScores[player.ActorNumber] = 0;
                    Debug.Log($"Ajout du joueur {player.NickName} (ID: {player.ActorNumber}) au score.");
                }
            }
        }
    }

    void Awake()
    {
        if (Instance == null)
            Instance = this;
    }

    [PunRPC]
    public void AddScore(int playerID, int points)
    {
        if (!playerScores.ContainsKey(playerID))
            playerScores[playerID] = 0;

        playerScores[playerID] += points;

        UpdateScoreUI();

        if (playerScores[playerID] >= winningScore)
        {
            Debug.Log($"Player {playerID} wins!");
            photonView.RPC("GameOver", RpcTarget.All, playerID);
        }
    }

    public void RegisterHit(int playerID, int scoreChange)
    {
        photonView.RPC("AddScore", RpcTarget.All, playerID, scoreChange); // Incrémente le score de 1 point
    }

    void UpdateScoreUI()
    {
        string scoreDisplay = "Leaderboard:\n\n";
        foreach (var player in PhotonNetwork.PlayerList)
        {
            int id = player.ActorNumber;
            int score = playerScores.ContainsKey(id) ? playerScores[id] : 0;
            scoreDisplay += $"Player {id} : {score}\n";
        }
        scoreText.text = scoreDisplay;

    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        if (!playerScores.ContainsKey(newPlayer.ActorNumber))
        {
            playerScores[newPlayer.ActorNumber] = 0;
            Debug.Log($"Nouveau joueur ajouté : {newPlayer.NickName} (ID: {newPlayer.ActorNumber})");
        }
    }

    [PunRPC]
    public void GameOver(int winnerID)
    {
        Debug.Log($"Game Over! Player {winnerID} wins!");
        UIManager.Instance.ShowVictoryScreen(winnerID);
    }
}

// public class ScoreManager : MonoBehaviourPunCallbacks
// {
//     public static ScoreManager Instance;
//     private Dictionary<int, int> playerScores = new Dictionary<int, int>(); // ID du joueur -> Score
//     public TextMeshProUGUI scoreText;
//     public int winningScore = 10;
    
//     void Start()
//     {
//         if (PhotonNetwork.IsConnected)
//         {
//             foreach (Player player in PhotonNetwork.PlayerList)
//             {
//                 if (!playerScores.ContainsKey(player.ActorNumber))
//                 {
//                     playerScores[player.ActorNumber] = 0;
//                     Debug.Log($"Ajout du joueur {player.NickName} (ID: {player.ActorNumber}) au score.");
//                 }
//             }
//         }
//     }

//     void Awake()
//     {
//         if (Instance == null)
//             Instance = this;
//     }

//     [PunRPC]
//     public void AddScore(int playerID, int points)
//     {
//         if (!playerScores.ContainsKey(playerID))
//             playerScores[playerID] = 0;

//         playerScores[playerID] += points;

//         UpdateScoreUI();

//         if (playerScores[playerID] >= winningScore)
//         {
//             Debug.Log($"Player {playerID} wins!");
//             photonView.RPC("GameOver", RpcTarget.All, playerID);
//         }
//     }

//     public void RegisterHit(int playerID)
//     {
//         photonView.RPC("AddScore", RpcTarget.All, playerID, 1); // Incrémente le score de 1 point
//     }

//     void UpdateScoreUI()
//     {
//         string scoreDisplay = "Leaderboard:\n\n";
//         foreach (var player in PhotonNetwork.PlayerList)
//         {
//             int id = player.ActorNumber;
//             int score = playerScores.ContainsKey(id) ? playerScores[id] : 0;
//             scoreDisplay += $"Player {id} : {score}\n";
//         }
//         scoreText.text = scoreDisplay;

//     }

//     public override void OnPlayerEnteredRoom(Player newPlayer)
//     {
//         if (!playerScores.ContainsKey(newPlayer.ActorNumber))
//         {
//             playerScores[newPlayer.ActorNumber] = 0;
//             Debug.Log($"Nouveau joueur ajouté : {newPlayer.NickName} (ID: {newPlayer.ActorNumber})");
//         }
//     }

//     [PunRPC]
//     public void GameOver(int winnerID)
//     {
//         Debug.Log($"Game Over! Player {winnerID} wins!");
//         UIManager.Instance.ShowVictoryScreen(winnerID);
//     }
// }
