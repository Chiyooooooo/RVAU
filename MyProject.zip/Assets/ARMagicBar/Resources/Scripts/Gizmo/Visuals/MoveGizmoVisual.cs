using ARMagicBar.Resources.Scripts.GizmoUI;
using UnityEngine;

namespace ARMagicBar.Resources.Scripts.Gizmo.Visuals
{
    //Attached to each XYZ Move Gizmo visual
    public class MoveGizmoVisual : MonoBehaviour, IGizmos
    {
        private void Start()
        {
            
        }
    }
}