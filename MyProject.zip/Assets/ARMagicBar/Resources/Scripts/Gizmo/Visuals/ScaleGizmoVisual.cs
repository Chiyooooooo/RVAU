using ARMagicBar.Resources.Scripts.GizmoUI;
using UnityEngine;

namespace ARMagicBar.Resources.Scripts.Gizmo.Visuals
{
    public class ScaleGizmoVisual : MonoBehaviour, IGizmos
    {
        private void Start()
        {
        }
    }
}