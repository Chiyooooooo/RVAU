using ARMagicBar.Resources.Scripts.GizmoUI;
using UnityEngine;

namespace ARMagicBar.Resources.Scripts.Gizmo.Visuals
{
    public class RotateGizmoVisual : MonoBehaviour, IGizmos
    {
        private void Start()
        {

        }
    }
} 