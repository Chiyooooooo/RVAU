using UnityEngine;

namespace ARMagicBar.Resources.Scripts.Gizmo
{
    //Attached to each XYZ Gizmo Object (Move Rotate Scale) * (XYZ)
    public class GizmoObject : MonoBehaviour
    {
        
    }
}