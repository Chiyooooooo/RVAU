using UnityEngine;

//Attached to each placement object
namespace ARMagicBar.Resources.Scripts.PlacementObjectVisual
{
    public class PlacementObjectVisual : MonoBehaviour
    {
        // private Renderer _renderer;
        // // Start is called before the first frame update
        // void Start()
        // {
        //     _renderer = GetComponentInParent<TransformableObjectSelectVisual>().ReturnRenderer();
        // }
        //
        // public Renderer GetRenderer()
        // {
        //     return _renderer;
        // }
        //
    }
}
