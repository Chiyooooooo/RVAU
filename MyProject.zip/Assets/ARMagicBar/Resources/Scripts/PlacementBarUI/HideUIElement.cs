using UnityEngine;

namespace ARMagicBar.Resources.Scripts.PlacementBarUI
{
    public class HideUIElement : MonoBehaviour
    {
    }
}