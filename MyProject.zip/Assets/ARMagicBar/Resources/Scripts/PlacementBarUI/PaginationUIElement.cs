using UnityEngine;

namespace ARMagicBar.Resources.Scripts.PlacementBarUI
{
    public class PaginationUIElement : MonoBehaviour
    {
        
    }
}