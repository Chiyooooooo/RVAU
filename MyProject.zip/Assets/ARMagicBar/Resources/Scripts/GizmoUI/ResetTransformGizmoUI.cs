using UnityEngine;

namespace ARMagicBar.Resources.Scripts.GizmoUI
{
    public class ResetTransformGizmoUI : MonoBehaviour, IGizmos
    {
        
    }
}