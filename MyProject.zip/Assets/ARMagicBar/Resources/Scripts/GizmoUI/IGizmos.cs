namespace ARMagicBar.Resources.Scripts.GizmoUI
{
    public interface IGizmos
    {
        
    }
}