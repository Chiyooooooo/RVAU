namespace ARMagicBar.Resources.Scripts.Other
{
    public static class AssetName
    {
        public const string NAME = "AR MagicBar";
    }
}