// using UnityEngine;

// public class TargetObject : MonoBehaviour
// {
//     void OnCollisionEnter(Collision collision)
//     {
//         if (collision.gameObject.CompareTag("Bullet"))
//         {
//             myBullet bullet = collision.gameObject.GetComponent<myBullet>();
//             if (bullet != null)
//             {
//                 int shooterID = bullet.GetShooterID();
//                 Debug.Log("ShooterID = " + shooterID);
//                 if (ScoreManager.Instance != null)
//                 {
//                     ScoreManager.Instance.RegisterHit(shooterID);
//                 }
//                 else
//                 {
//                     Debug.LogError("ScoreManager.Instance est NULL !");
//                 }
//             }

//             Destroy(gameObject); // Optionnel : détruire l'objet touché
//         }
//     }
// }


using UnityEngine;

public class TargetObject : MonoBehaviour
{
    public int scoreValue = 1; // Valeur par défaut, peut être positive ou négative

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Bullet"))
        {
            myBullet bullet = collision.gameObject.GetComponent<myBullet>();
            if (bullet != null)
            {
                int shooterID = bullet.GetShooterID();
                Debug.Log($"ShooterID = {shooterID}, ScoreValue = {scoreValue}");

                if (ScoreManager.Instance != null)
                {
                    ScoreManager.Instance.RegisterHit(shooterID, scoreValue);
                }
                else
                {
                    Debug.LogError("ScoreManager.Instance est NULL !");
                }
            }

            Destroy(gameObject); // Optionnel : détruire l'objet touché
        }
    }
}