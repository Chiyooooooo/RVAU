﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UltimateProceduralPrimitivesFREE
{
  [System.Serializable]
  public class NotAvailableInFreeVersion
  {
    [ReadOnly] public string FreeVersion = "NotAvailable";
  }
}