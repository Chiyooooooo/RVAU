using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;
    public GameObject victoryScreen;
    public TextMeshProUGUI victoryText; // Remplace Text par TextMeshProUGUI

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        victoryScreen.SetActive(false); // Cache l'écran de victoire au début
    }

    public void ShowVictoryScreen(int winnerID)
    {
        victoryText.text = $"Player {winnerID} Wins!";
        victoryScreen.SetActive(true);
    }
}
