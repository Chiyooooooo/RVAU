using UnityEngine;

public class myBullet : MonoBehaviour
{
    private int shooterID;

    public void SetShooterID(int id)
    {
        shooterID = id;
    }

    public int GetShooterID()
    {
        return shooterID;
    }
}