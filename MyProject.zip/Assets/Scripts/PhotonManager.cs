using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

public class PhotonManager : MonoBehaviourPunCallbacks
{
    void Start()
    {
        if (!PhotonNetwork.IsConnected)
        {
            PhotonNetwork.ConnectUsingSettings();
            PhotonNetwork.AutomaticallySyncScene = true; // Ensures all players see the same scene
        }
    }

    public override void OnConnectedToMaster()
    {
        Debug.Log("Connected to Master Server!");
        PhotonNetwork.JoinLobby(); // Wait until the player joins the lobby before matchmaking
    }

    public override void OnJoinedLobby()
    {
        Debug.Log("Joined Photon Lobby. Now joining or creating a room...");
//        PhotonNetwork.JoinOrCreateRoom("ARRoom", new RoomOptions { MaxPlayers = 2 }, TypedLobby.Default);
        PhotonNetwork.JoinOrCreateRoom("ARRoom", new RoomOptions { MaxPlayers = 10 }, TypedLobby.Default);

    }

    public override void OnJoinedRoom()
    {
        Debug.Log("✅ Successfully joined room: " + PhotonNetwork.CurrentRoom.Name);
        Debug.Log("📡 Players in room: " + PhotonNetwork.CurrentRoom.PlayerCount);

        foreach (var player in PhotonNetwork.PlayerList)
        {
            Debug.Log("👤 Player: " + player.NickName + " (ID: " + player.UserId + ")");
        }
    }




}

