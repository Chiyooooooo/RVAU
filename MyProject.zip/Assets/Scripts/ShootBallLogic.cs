using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class ShootBallLogic : MonoBehaviourPun
{
    private Camera mainCam;

    [SerializeField] private GameObject ballPrefab;
    [SerializeField] private float ballForwardForce = 500f;
    
    void Start()
    {
        mainCam = FindObjectOfType<Camera>();
        UIButtonHandler.OnUIShootButtonClicked += ShootBallOnButton;
    }

    private void ShootBallOnButton()
    {
        Vector3 spawnPosition = mainCam.transform.position + mainCam.transform.forward * 0.1f;
        Quaternion spawnRotation = mainCam.transform.rotation;

        //GameObject spawnedBall = PhotonNetwork.Instantiate(ballPrefab.name, spawnPosition, spawnRotation);
        
        GameObject spawnedBall = PhotonNetwork.Instantiate("PlaceableObjects/" + ballPrefab.name, spawnPosition, spawnRotation);
        //GameObject spawnedBall = PhotonNetwork.Instantiate("PlaceableObjects/", spawnPosition, spawnRotation);

        Rigidbody rb = spawnedBall.GetComponent<Rigidbody>();

        if (rb != null)
        {
            rb.AddForce(mainCam.transform.forward * ballForwardForce);
        }

        Destroy(spawnedBall, 5f);
    }
}




