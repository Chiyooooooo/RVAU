using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class ForceAssignPhotonComponents : MonoBehaviourPun
{
    private void Awake()
    {
        PhotonView photonView = GetComponent<PhotonView>();
        PhotonTransformViewClassic transformView = GetComponent<PhotonTransformViewClassic>();

        if (photonView != null)
        {
            if (photonView.ObservedComponents == null)
                photonView.ObservedComponents = new System.Collections.Generic.List<Component>();

            if (transformView != null && !photonView.ObservedComponents.Contains(transformView))
            {
                photonView.ObservedComponents.Add(transformView);
                photonView.Synchronization = ViewSynchronization.UnreliableOnChange; // Ensures updates
            }
        }
    }
}
