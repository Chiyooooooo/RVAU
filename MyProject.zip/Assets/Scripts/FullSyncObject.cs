using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;


public class FullSyncObject : MonoBehaviourPun, IPunObservable
{
    // Local transform values
    private Vector3 networkPosition;
    private Quaternion networkRotation;
    private Vector3 networkScale;

    // Deletion flag
    private bool markedForDeletion = false;

    void Awake()
    {
        networkPosition = transform.position;
        networkRotation = transform.rotation;
        networkScale = transform.localScale;
    }

    // IPunObservable: sync position, rotation, scale, and deletion
    public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {
        if (stream.IsWriting)
        {
            // If we own this object, send the data
            stream.SendNext(transform.position);
            stream.SendNext(transform.rotation);
            stream.SendNext(transform.localScale);
            stream.SendNext(markedForDeletion);
        }
        else
        {
            // Receive data
            networkPosition = (Vector3)stream.ReceiveNext();
            networkRotation = (Quaternion)stream.ReceiveNext();
            networkScale = (Vector3)stream.ReceiveNext();
            markedForDeletion = (bool)stream.ReceiveNext();

            // Apply changes immediately
            transform.position = networkPosition;
            transform.rotation = networkRotation;
            transform.localScale = networkScale;

            // Handle deletion if flagged
            if (markedForDeletion)
            {
                if (photonView != null && photonView.IsMine)
                {
                    PhotonNetwork.Destroy(gameObject);
                }
                else
                {
                    Destroy(gameObject);
                }
            }
        }
    }

    // Public method for any transform update
    public void SetTransformValues(Vector3 newPosition, Quaternion newRotation, Vector3 newScale)
    {
        if (!photonView.IsMine)
        {
            photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
        }

        transform.position = newPosition;
        transform.rotation = newRotation;
        transform.localScale = newScale;
    }

    // Public method to delete an object for all players
    public void DeleteObject()
    {
        if (!photonView.IsMine)
        {
            photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
        }

        markedForDeletion = true;
    }
}
