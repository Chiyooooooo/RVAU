using System.Collections;
using UnityEngine;
using Photon.Pun;

public class FullSyncObject : MonoBehaviourPun, IPunObservable
{
    private Vector3 networkPosition;
    private Quaternion networkRotation;
    private Vector3 networkScale;
    private bool markedForDeletion = false;

    [SerializeField] private float positionLerpSpeed = 10f;
    [SerializeField] private float rotationLerpSpeed = 10f;
    [SerializeField] private float scaleLerpSpeed = 10f;

    void Awake()
    {
        networkPosition = transform.position;
        networkRotation = transform.rotation;
        networkScale = transform.localScale;
    }

    void Update()
    {
        if (!photonView.IsMine) // Only apply interpolation for remote clients
        {
            transform.position = Vector3.Lerp(transform.position, networkPosition, Time.deltaTime * positionLerpSpeed);
            transform.rotation = Quaternion.Slerp(transform.rotation, networkRotation, Time.deltaTime * rotationLerpSpeed);
            transform.localScale = Vector3.Lerp(transform.localScale, networkScale, Time.deltaTime * scaleLerpSpeed);
        }
    }

    public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
    {
        if (stream.IsWriting)
        {
            // Send position, rotation, scale, and deletion flag
            stream.SendNext(transform.position);
            stream.SendNext(transform.rotation);
            stream.SendNext(transform.localScale);
            stream.SendNext(markedForDeletion);
        }
        else
        {
            // Receive position, rotation, scale, and deletion flag
            networkPosition = (Vector3)stream.ReceiveNext();
            networkRotation = (Quaternion)stream.ReceiveNext();
            networkScale = (Vector3)stream.ReceiveNext();
            markedForDeletion = (bool)stream.ReceiveNext();

            if (markedForDeletion)
            {
                DeleteObjectLocally();
            }
        }
    }

    // Ensures correct ownership and applies transform updates
    public void SetTransformValues(Vector3 newPosition, Quaternion newRotation, Vector3 newScale)
    {
        if (!photonView.IsMine)
        {
            photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
        }

        transform.position = newPosition;
        transform.rotation = newRotation;
        transform.localScale = newScale;

        // Sync transform across all clients
        photonView.RPC("RPC_UpdateTransform", RpcTarget.OthersBuffered, newPosition, newRotation, newScale);
    }

    // Smoothly sync transform values via RPC
    [PunRPC]
    private void RPC_UpdateTransform(Vector3 newPosition, Quaternion newRotation, Vector3 newScale)
    {
        networkPosition = newPosition;
        networkRotation = newRotation;
        networkScale = newScale;
    }

    // Public method to update only the scale
    public void ChangeScale(Vector3 newScale)
    {
        if (!photonView.IsMine)
        {
            photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
        }

        transform.localScale = newScale;
        photonView.RPC("RPC_UpdateScale", RpcTarget.OthersBuffered, newScale);
    }

    [PunRPC]
    private void RPC_UpdateScale(Vector3 newScale)
    {
        networkScale = newScale;
    }

    // Public method to delete an object across all clients
    public void DeleteObject()
    {
        if (!photonView.IsMine)
        {
            photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
        }

        markedForDeletion = true;
        photonView.RPC("RPC_DeleteObject", RpcTarget.AllBuffered);
    }

    // RPC to delete object across network
    [PunRPC]
    private void RPC_DeleteObject()
    {
        DeleteObjectLocally();
    }

    // Ensures object is properly destroyed
    private void DeleteObjectLocally()
    {
        if (photonView.IsMine)
        {
            PhotonNetwork.Destroy(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}