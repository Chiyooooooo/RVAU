// using System;
// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;

// public class EnablePhysicsOnEvent : MonoBehaviour
// {
//     [SerializeField] private Rigidbody rb; 

//     void Start()
//     {

//         // UIButtonHandler.OnUIStartButtonClicked += StartPhysicsOnButtonClicked;
//         // rb.isKinematic = true;
//         rb.isKinematic = false;
//         rb.useGravity = true;
//     }

//     private void StartPhysicsOnButtonClicked()
//     {
//         rb.isKinematic = false;
//         rb.useGravity = true;
//     }

//     private void OnDestroy()
//     {
//         UIButtonHandler.OnUIStartButtonClicked -= StartPhysicsOnButtonClicked;
//     }
// }

using UnityEngine;

public class EnablePhysicsOnEvent : MonoBehaviour
{
    [SerializeField] private Rigidbody rb; 

    void Start()
    {
        // Let the pig fall immediately
        rb.isKinematic = false;
        rb.useGravity = true;
    }

    // If you no longer need button logic:
    // remove the method and OnDestroy unsubscribing
}