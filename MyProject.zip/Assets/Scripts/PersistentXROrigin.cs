using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersistentXROrigin : MonoBehaviour
{
    private static PersistentXROrigin instance;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
