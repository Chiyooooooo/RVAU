using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;


public class TransformObject : MonoBehaviourPun
{
    public void RotateObject(float angle)
    {
        if (!photonView.IsMine) return; // Only the owner can modify
        Quaternion newRotation = transform.rotation * Quaternion.Euler(0, angle, 0);
        photonView.RPC("RPC_SyncRotation", RpcTarget.AllBuffered, newRotation);
    }

    public void ScaleObject(float scaleFactor)
    {
        if (!photonView.IsMine) return; // Only the owner can modify
        Vector3 newScale = transform.localScale * scaleFactor;
        photonView.RPC("RPC_SyncScale", RpcTarget.AllBuffered, newScale);
    }

    [PunRPC]
    private void RPC_SyncRotation(Quaternion newRotation)
    {
        transform.rotation = newRotation;
    }

    [PunRPC]
    private void RPC_SyncScale(Vector3 newScale)
    {
        transform.localScale = newScale;
    }
}
