using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersistentXRCamera : MonoBehaviour
{
    private static PersistentXRCamera instance;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject); // Prevent duplicate cameras
        }
    }
}
