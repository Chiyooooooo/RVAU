using System.Collections;
using UnityEngine;
using Photon.Pun;

public class PigSpawner : MonoBehaviourPunCallbacks
{
    public GameObject pigPrefab; // Assign this in the Inspector
    public float spawnInterval = 2f; // Time between spawns

    // Fix: Use floats instead of integer division
    public Vector3 spawnAreaSize = new Vector3(0.5f, 0f, 0.5f); 

    private void Start()
    {
        Debug.Log("[PigSpawner] Start called!");

        // Option A: Let EVERY player spawn pigs if they're in a room
        // If you only want MasterClient to spawn, use: if (PhotonNetwork.IsMasterClient)
        if (PhotonNetwork.InRoom)
        {
            Debug.Log("[PigSpawner] InRoom => Starting pig spawn coroutine.");
            StartCoroutine(SpawnPigsRoutine());
        }
        else
        {
            StartCoroutine(SpawnPigsRoutine());
            Debug.Log("[PigSpawner] Not in a room yet. No spawns will occur.");
        }
    }

    IEnumerator SpawnPigsRoutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawnInterval);
            SpawnPig();
        }
    }

    void SpawnPig()
    {
        if (pigPrefab == null)
        {
            Debug.LogError("[PigSpawner] ERROR: Pig prefab is not assigned!");
            return;
        }

        // Check Photon states
        if (!PhotonNetwork.InRoom || !PhotonNetwork.IsConnectedAndReady)
        {
            Debug.LogWarning("[PigSpawner] Photon is not in-room or not ready. Cannot spawn pig.");
            return;
        }

        // Generate a random spawn position within the specified area
        // Fix: Use floats for random range
        float randX = Random.Range(-spawnAreaSize.x, spawnAreaSize.x);
        float randZ = Random.Range(-spawnAreaSize.z, spawnAreaSize.z);

        // Example: spawn around y=0.1 plus a random offset
        float randY = 0.1f + Random.Range(-0.05f, 0.33f);

        Vector3 spawnPosition = new Vector3(randX, randY, randZ);

        // Ensure the prefab name matches the file in Resources folder (Pig.prefab)
        GameObject pigInstance = PhotonNetwork.Instantiate("Pig", spawnPosition, Quaternion.identity);

        Debug.Log($"[PigSpawner] Spawned a pig at {spawnPosition} with PhotonView ID: {pigInstance.GetComponent<PhotonView>().ViewID}");
    }
}
