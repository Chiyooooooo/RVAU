using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;
using Quaternion = UnityEngine.Quaternion;
using Vector3 = UnityEngine.Vector3;
using Photon.Pun;

// public class ResetRbPositionOfObject : MonoBehaviourPun
// {
//     [SerializeField] private Rigidbody rb;

//     private Vector3 rbStartPosition;
//     private Quaternion rbStartRotation;
    
//     void Start()
//     {
//         UIButtonHandler.OnUIResetButtonClicked += ResetRbPositionOnButtonClicked;

//         rbStartPosition = rb.transform.localPosition;
//         rbStartRotation = rb.transform.localRotation;
//     }

//     private void ResetRbPositionOnButtonClicked()
//     {
//         photonView.RPC("RPC_ResetObjectPosition", RpcTarget.AllBuffered);
//     }

//     [PunRPC]
//     private void RPC_ResetObjectPosition()
//     {
//         rb.isKinematic = true;
//         rb.transform.localPosition = rbStartPosition;
//         rb.transform.localRotation = rbStartRotation;
//         rb.velocity = Vector3.zero;
//         rb.angularVelocity = Vector3.zero;
//     }

//     private void OnDestroy()
//     {
//         UIButtonHandler.OnUIResetButtonClicked -= ResetRbPositionOnButtonClicked;
//     }
// }


using UnityEngine;
using Photon.Pun;

public class ResetRbPositionOfObject : MonoBehaviourPun
{
    [SerializeField] private Rigidbody rb;

    private Vector3 rbStartPosition;
    private Quaternion rbStartRotation;

    void Start()
    {
        UIButtonHandler.OnUIResetButtonClicked += ResetRbPositionOnButtonClicked;

        if (rb == null)
        {
            Debug.LogError("❌ ERROR: Rigidbody (`rb`) is NOT assigned in " + gameObject.name + ". Make sure this object has a Rigidbody component.");
            return;
        }

        rbStartPosition = rb.transform.localPosition;
        rbStartRotation = rb.transform.localRotation;
        Debug.Log("✅ Rigidbody assigned successfully: " + rb.name);
    }

    private void ResetRbPositionOnButtonClicked()
    {
        if (rb == null)
        {
            Debug.LogError("❌ ERROR: Rigidbody (`rb`) is NULL when Reset is called on " + gameObject.name + ". Ensure it is assigned.");
            return;
        }

        if (!rb.gameObject.activeInHierarchy)
        {
            Debug.LogWarning("⚠️ WARNING: " + gameObject.name + " is disabled and cannot be reset.");
            return;
        }

        if (!photonView.IsMine) 
        {
            Debug.Log("⚠️ Skipping reset because this is not my object: " + gameObject.name);
            return;
        }

        Debug.Log("🔄 Resetting object: " + rb.name);
        photonView.RPC("RPC_ResetObjectPosition", RpcTarget.AllBuffered);
    }

    [PunRPC]
    private void RPC_ResetObjectPosition()
    {
        if (rb == null)
        {
            Debug.LogError("❌ ERROR: Rigidbody (`rb`) is NULL inside RPC_ResetObjectPosition on " + gameObject.name);
            return;
        }

        Debug.Log("🔄 Resetting position: " + rb.name);

        rb.isKinematic = true;
        rb.transform.localPosition = rbStartPosition;
        rb.transform.localRotation = rbStartRotation;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        Debug.Log("✅ Rigidbody Reset Successful: " + rb.name);
    }

    private void OnDestroy()
    {
        UIButtonHandler.OnUIResetButtonClicked -= ResetRbPositionOnButtonClicked;
    }
}
