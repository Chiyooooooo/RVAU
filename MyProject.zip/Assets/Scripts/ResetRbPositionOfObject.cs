using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;
using Quaternion = UnityEngine.Quaternion;
using Vector3 = UnityEngine.Vector3;
using Photon.Pun;

public class ResetRbPositionOfObject : MonoBehaviourPun
{
    [SerializeField] private Rigidbody rb;

    private Vector3 rbStartPosition;
    private Quaternion rbStartRotation;

    void Start()
    {
        UIButtonHandler.OnUIResetButtonClicked += ResetRbPositionOnButtonClicked;

        if (rb == null)
        {
            Debug.LogError("ERROR: Rigidbody (`rb`) is NOT assigned in " + gameObject.name + 
                           ". Make sure this object has a Rigidbody component.");
            return;
        }

        // Store the starting local position/rotation
        rbStartPosition = rb.transform.localPosition;
        rbStartRotation = rb.transform.localRotation;
        Debug.Log("Rigidbody assigned successfully: " + rb.name);
    }

    private void ResetRbPositionOnButtonClicked()
    {
        if (rb == null)
        {
            Debug.LogError("ERROR: Rigidbody (`rb`) is NULL when Reset is called on " + gameObject.name + 
                           ". Ensure it is assigned.");
            return;
        }

        if (!rb.gameObject.activeInHierarchy)
        {
            Debug.LogWarning("WARNING: " + gameObject.name + " is disabled and cannot be reset.");
            return;
        }

        // Only reset if we own this object in Photon
        if (!photonView.IsMine) 
        {
            Debug.Log("Skipping reset because this is not my object: " + gameObject.name);
            return;
        }

        Debug.Log("Resetting object: " + rb.name);
        photonView.RPC("RPC_ResetObjectPosition", RpcTarget.AllBuffered);
    }

    [PunRPC]
    private void RPC_ResetObjectPosition()
    {
        if (rb == null)
        {
            Debug.LogError("ERROR: Rigidbody (`rb`) is NULL inside RPC_ResetObjectPosition on " + gameObject.name);
            return;
        }

        Debug.Log("Resetting position: " + rb.name);

        // 1) Temporarily disable physics to snap the pig back
        rb.isKinematic = true;
        rb.transform.localPosition = rbStartPosition;
        rb.transform.localRotation = rbStartRotation;
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        // 2) Re-enable gravity and make it dynamic again
        rb.isKinematic = false; 
        rb.useGravity = true;

        Debug.Log("Rigidbody Reset Successful: " + rb.name);
    }

    private void OnDestroy()
    {
        UIButtonHandler.OnUIResetButtonClicked -= ResetRbPositionOnButtonClicked;

        if (photonView != null && photonView.IsMine)
        {
            PhotonNetwork.RemoveRPCs(photonView);
            PhotonNetwork.Destroy(gameObject);
        }
    }
}
